package com.bench.codmoverlay

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper

object AimEngine {
    var silentAimEnabled = false
    var aimbotHeadsnap = false
    var triggerBotEnabled = false
    var noRecoilEnabled = false

    private val RECOIL_OFFSETS = listOf(
        0f to -8f, 0f to -6f, 2f to -5f, -2f to -5f,
        0f to -4f, 3f to -4f, -3f to -3f, 0f to -3f
    )
    private var recoilStep = 0

    fun onEnemiesDetected(enemies: List<ESPEngine.EnemyBox>, service: AimAccessibilityService) {
        if (enemies.isEmpty()) { recoilStep = 0; return }
        val screenCx = service.resources.displayMetrics.widthPixels / 2f
        val screenCy = service.resources.displayMetrics.heightPixels / 2f
        val target = enemies.minByOrNull { e ->
            Math.hypot((e.centerX - screenCx).toDouble(), (e.centerY - screenCy).toDouble())
        } ?: return
        val aimX = target.centerX
        val aimY = if (aimbotHeadsnap) target.headY else target.centerY
        if (silentAimEnabled) injectTap(aimX, aimY, service)
        if (triggerBotEnabled) {
            val dist = Math.hypot((aimX - screenCx).toDouble(), (aimY - screenCy).toDouble())
            if (dist < 60) injectTap(screenCx, screenCy, service)
        }
        if (noRecoilEnabled) applyNoRecoil(service)
    }

    private fun injectTap(x: Float, y: Float, service: AimAccessibilityService) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        service.dispatchGesture(gesture, null, null)
    }

    private fun applyNoRecoil(service: AimAccessibilityService) {
        val idx = recoilStep.coerceAtMost(RECOIL_OFFSETS.size - 1)
        val (dx, dy) = RECOIL_OFFSETS[idx]
        val screenCx = service.resources.displayMetrics.widthPixels / 2f
        val screenCy = service.resources.displayMetrics.heightPixels / 2f
        val path = Path().apply { moveTo(screenCx, screenCy); lineTo(screenCx + dx, screenCy + dy) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 30)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        service.dispatchGesture(gesture, null, null)
        recoilStep++
    }

    fun resetRecoil() { recoilStep = 0 }
}
