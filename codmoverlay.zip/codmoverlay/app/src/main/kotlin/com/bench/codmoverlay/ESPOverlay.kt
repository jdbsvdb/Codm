package com.bench.codmoverlay

object ESPOverlay {
    var espEnabled = true
    var radarEnabled = true
}
