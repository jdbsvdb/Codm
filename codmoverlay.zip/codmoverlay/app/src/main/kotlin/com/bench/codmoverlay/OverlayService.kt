package com.bench.codmoverlay

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.view.WindowManager.LayoutParams.*
import androidx.core.app.NotificationCompat

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: HUDView
    private lateinit var projection: MediaProjection
    private lateinit var virtualDisplay: VirtualDisplay
    private lateinit var imageReader: ImageReader

    private val captureThread = HandlerThread("capture").also { it.start() }
    private val captureHandler = Handler(captureThread.looper)

    private val screenW get() = resources.displayMetrics.widthPixels
    private val screenH get() = resources.displayMetrics.heightPixels
    private val CAPTURE_W = 720
    private val CAPTURE_H = 1280

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        val resultCode = intent!!.getIntExtra("resultCode", 0)
        val data = intent.getParcelableExtra<Intent>("data")!!
        val pm = getSystemService(MediaProjectionManager::class.java)
        projection = pm.getMediaProjection(resultCode, data)
        imageReader = ImageReader.newInstance(CAPTURE_W, CAPTURE_H, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection.createVirtualDisplay(
            "bench_capture", CAPTURE_W, CAPTURE_H,
            resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.surface, null, captureHandler
        )
        setupOverlay()
        startCaptureLoop()
        return START_NOT_STICKY
    }

    private fun setupOverlay() {
        windowManager = getSystemService(WindowManager::class.java)
        overlayView = HUDView(this)
        val params = LayoutParams(
            MATCH_PARENT, MATCH_PARENT, TYPE_APPLICATION_OVERLAY,
            FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCHABLE or FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        windowManager.addView(overlayView, params)

        val controlPanel = ControlPanelView(this)
        val cpParams = LayoutParams(
            WRAP_CONTENT, WRAP_CONTENT, TYPE_APPLICATION_OVERLAY,
            FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; topMargin = 200 }
        windowManager.addView(controlPanel, cpParams)
    }

    private fun startCaptureLoop() {
        val scaleX = screenW.toFloat() / CAPTURE_W
        val scaleY = screenH.toFloat() / CAPTURE_H
        captureHandler.post(object : Runnable {
            override fun run() {
                val image = imageReader.acquireLatestImage()
                if (image != null) {
                    val plane = image.planes[0]
                    val buf = plane.buffer
                    val rowPadding = plane.rowStride - plane.pixelStride * CAPTURE_W
                    val bmp = Bitmap.createBitmap(
                        CAPTURE_W + rowPadding / plane.pixelStride,
                        CAPTURE_H, Bitmap.Config.ARGB_8888
                    )
                    bmp.copyPixelsFromBuffer(buf)
                    image.close()
                    val enemies = ESPEngine.scan(bmp, scaleX, scaleY)
                    bmp.recycle()
                    Handler(Looper.getMainLooper()).post {
                        overlayView.updateEnemies(enemies)
                        AimAccessibilityService.instance?.let { svc ->
                            AimEngine.onEnemiesDetected(enemies, svc)
                        }
                    }
                }
                captureHandler.postDelayed(this, 33)
            }
        })
    }

    override fun onDestroy() {
        virtualDisplay.release()
        projection.stop()
        imageReader.close()
        windowManager.removeView(overlayView)
        captureThread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun buildNotification(): Notification {
        val ch = NotificationChannel("bench", "bench", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        return NotificationCompat.Builder(this, "bench")
            .setContentTitle("bench running")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }
}
