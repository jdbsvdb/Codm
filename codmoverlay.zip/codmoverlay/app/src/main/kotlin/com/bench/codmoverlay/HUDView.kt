package com.bench.codmoverlay

import android.content.Context
import android.graphics.*
import android.view.View

class HUDView(context: Context) : View(context) {
    private var enemies: List<ESPEngine.EnemyBox> = emptyList()

    private val boxPaint = Paint().apply { color = Color.RED; style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = true }
    private val headPaint = Paint().apply { color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 2f }
    private val linePaint = Paint().apply { color = Color.argb(180, 255, 0, 0); strokeWidth = 1.5f }
    private val textPaint = Paint().apply { color = Color.WHITE; textSize = 28f; isFakeBoldText = true; setShadowLayer(4f, 1f, 1f, Color.BLACK) }
    private val radarBgPaint = Paint().apply { color = Color.argb(160, 0, 0, 0); style = Paint.Style.FILL }

    fun updateEnemies(list: List<ESPEngine.EnemyBox>) { enemies = list; postInvalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!ESPOverlay.espEnabled) return
        val screenCx = width / 2f
        val screenCy = height / 2f
        enemies.forEachIndexed { i, e ->
            canvas.drawRect(e.rect, boxPaint)
            val headRadius = (e.rect.width() / 2f).coerceAtMost(30f)
            canvas.drawCircle(e.centerX, e.headY, headRadius, headPaint)
            canvas.drawLine(screenCx, height.toFloat(), e.centerX, e.rect.bottom, linePaint)
            val dist = Math.hypot((e.centerX - screenCx).toDouble(), (e.centerY - screenCy).toDouble()).toInt()
            canvas.drawText("T${i+1} ~${dist}px", e.rect.left, e.rect.top - 8f, textPaint)
        }
        if (ESPOverlay.radarEnabled) drawRadar(canvas, screenCx, screenCy)
    }

    private fun drawRadar(canvas: Canvas, scx: Float, scy: Float) {
        val rx = 80f; val ry = height - 100f; val r = 70f
        canvas.drawCircle(rx, ry, r, radarBgPaint)
        val dotPaint = Paint().apply { color = Color.RED; style = Paint.Style.FILL }
        enemies.forEach { e ->
            val dx = ((e.centerX - scx) / scx) * r * 0.8f
            val dy = ((e.centerY - scy) / scy) * r * 0.8f
            canvas.drawCircle(rx + dx, ry + dy, 5f, dotPaint)
        }
        dotPaint.color = Color.GREEN
        canvas.drawCircle(rx, ry, 6f, dotPaint)
    }
}
