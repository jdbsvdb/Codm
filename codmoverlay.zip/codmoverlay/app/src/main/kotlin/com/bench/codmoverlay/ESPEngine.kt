package com.bench.codmoverlay

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF

object ESPEngine {
    private const val TARGET_R = 255
    private const val TARGET_G = 30
    private const val TARGET_B = 30
    private const val TOLERANCE = 60
    private const val MIN_CLUSTER_PX = 80
    private const val SAMPLE_STEP = 3

    data class EnemyBox(
        val rect: RectF,
        val centerX: Float,
        val centerY: Float,
        val headY: Float
    )

    fun scan(bmp: Bitmap, scaleX: Float, scaleY: Float): List<EnemyBox> {
        val w = bmp.width
        val h = bmp.height
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)
        val hits = mutableListOf<Pair<Int,Int>>()
        for (y in 0 until h step SAMPLE_STEP) {
            for (x in 0 until w step SAMPLE_STEP) {
                val px = pixels[y * w + x]
                if (isTargetColor(px)) hits.add(x to y)
            }
        }
        return clusterToBboxes(hits, scaleX, scaleY)
    }

    private fun isTargetColor(px: Int): Boolean {
        val r = Color.red(px)
        val g = Color.green(px)
        val b = Color.blue(px)
        return Math.abs(r - TARGET_R) < TOLERANCE &&
               Math.abs(g - TARGET_G) < TOLERANCE &&
               Math.abs(b - TARGET_B) < TOLERANCE
    }

    private fun clusterToBboxes(hits: List<Pair<Int,Int>>, scaleX: Float, scaleY: Float): List<EnemyBox> {
        if (hits.isEmpty()) return emptyList()
        val clusters = mutableListOf<MutableList<Pair<Int,Int>>>()
        val MERGE_DIST = 40
        for (hit in hits) {
            val nearest = clusters.firstOrNull { cluster ->
                cluster.any { p -> Math.abs(p.first - hit.first) < MERGE_DIST && Math.abs(p.second - hit.second) < MERGE_DIST }
            }
            if (nearest != null) nearest.add(hit) else clusters.add(mutableListOf(hit))
        }
        return clusters.filter { it.size >= MIN_CLUSTER_PX / (SAMPLE_STEP * SAMPLE_STEP) }
            .map { cluster ->
                val minX = cluster.minOf { it.first }.toFloat() * scaleX
                val maxX = cluster.maxOf { it.first }.toFloat() * scaleX
                val minY = cluster.minOf { it.second }.toFloat() * scaleY
                val maxY = cluster.maxOf { it.second }.toFloat() * scaleY
                val cx = (minX + maxX) / 2f
                val cy = (minY + maxY) / 2f
                val headY = minY + (maxY - minY) * 0.15f
                EnemyBox(RectF(minX, minY, maxX, maxY), cx, cy, headY)
            }
    }
}
