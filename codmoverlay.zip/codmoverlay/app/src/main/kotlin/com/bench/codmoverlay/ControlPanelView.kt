package com.bench.codmoverlay

import android.content.Context
import android.graphics.Color
import android.view.*
import android.widget.*

class ControlPanelView(context: Context) : LinearLayout(context) {
    private var dX = 0f; private var dY = 0f

    init {
        orientation = VERTICAL
        setBackgroundColor(Color.argb(200, 20, 20, 20))
        setPadding(16, 16, 16, 16)
        addToggle("ESP Boxes", true)  { ESPOverlay.espEnabled = it }
        addToggle("Radar", true)      { ESPOverlay.radarEnabled = it }
        addToggle("Silent Aim", false){ AimEngine.silentAimEnabled = it }
        addToggle("Head Snap", false) { AimEngine.aimbotHeadsnap = it }
        addToggle("Trigger Bot", false){ AimEngine.triggerBotEnabled = it }
        addToggle("No Recoil", false) { AimEngine.noRecoilEnabled = it }
        setupDrag()
    }

    private fun addToggle(label: String, default: Boolean, onChanged: (Boolean) -> Unit) {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            setPadding(0, 4, 0, 4)
        }
        val tv = TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 13f
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }
        val sw = Switch(context).apply {
            isChecked = default
            setOnCheckedChangeListener { _, v -> onChanged(v) }
        }
        row.addView(tv); row.addView(sw); addView(row)
    }

    private fun setupDrag() {
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dX = v.x - e.rawX; dY = v.y - e.rawY; true }
                MotionEvent.ACTION_MOVE -> { v.x = e.rawX + dX; v.y = e.rawY + dY; true }
                else -> false
            }
        }
    }
}
